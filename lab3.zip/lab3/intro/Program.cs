﻿using System;

namespace intro
{
    class Program
    {
        static void Main(string[] args)
        {
            new Program();
        }

        // Play with C# Language

        // Program is constructor Put access level (public, private) but no return value Same Name as Class
        Program(){
            Console.WriteLine("Hello from C#");
            SayHello();
        }
        // First Method
        /*Syntax
            Access level (optional)
            Return Type
            Name
            Paramaters (optional)
             */
        public string SayHello(){
            Console.WriteLine("Hello from a Method");
            DataTypes();
            return "something";
        }

        public void DataTypes()
        {
            int a = 1;
            string name = "Doug";
            bool found = false;
            double d = 1.45;

            float f = 1.23f;
            char c = 'd';

            // Arrays
            string[] names = new string[23]; // 23 is the array length

            for (int i = 0; i < 23; i++)
            {
                // Add elements to array
                names[i] = "Value: " + i;
                Console.WriteLine(names[i]);
                
            }
            



        }
    }
}
