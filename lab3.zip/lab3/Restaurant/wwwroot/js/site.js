﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

// $('#errorAlert').hide();

// **************************************************************
// Register DISH Logic
// *************************************************************

function RegisterDishInfo(){

    let name = $('#dishName').val();
    let price = $('#dishPrice').val();
    let image = $('#dishImg').val();
    let description = $('#dishDescription').val();
    let vegan = $("#isVegan").is(":checked");

    $("#dishName, #dishPrice").removeClass( "border border-danger" );

    // Do Validations

    let validDouble = parseFloat(price);

    if (!name || !validDouble) {

        if (!name) {   	
            $( "#dishName" ).addClass( "border border-danger" );
            $('#dishName').attr("placeholder","Please Enter a Name");
        }

        if (!validDouble) {
            $('#dishPrice').val('');
            $( "#dishPrice" ).addClass( "border border-danger" );
            $('#dishPrice').attr("placeholder","Please enter a valid number");
        }
    
        $('#errorAlert').show();
        return;
    }

    let dish = {

        Name: name,
        Price: validDouble,
        Image: image,
        Description: description,
        Vegan: vegan
    };

    console.log("Sending Dish to server");

    $.ajax({
        type: "POST",
        url: "/Dish/Register",
        data: JSON.stringify(dish),
        contentType: "application/json; charset=utf-8",
        success: function (res) {
            console.log('Dish POST Ended');
            console.log('Server Says: ', res);

            // Clear Inputs
            $('#dishName').val('');
            $('#dishPrice').val('');
            $('#dishImg').val('');
            $('#dishDescription').val('');
            $("#isVegan").prop( "checked", false );

            // Reset error fields
            $("#errorAlert").hide();
            $("#dishName, #dishPrice").removeClass( "border border-danger" );
            $("#dishName, #dishPrice").removeAttr("placeholder");
            
        }
    });
}

// **************************************************************
// Register EMPLOYEE Logic
// *************************************************************

function SendTest(){

    let fName = $('#txtFirstName').val();
    let lName = $('#txtLastName').val();
    let phNum = $('#txtPhNumber').val();
    let pos = $('#txtPosition').val();
    let sal = $('#txtSalary').val();

    $("#txtFirstName, #txtLastName, #txtSalary").removeClass( "border border-danger" );

    let validDouble = parseFloat(sal);    

    if (!fName || !lName || !validDouble) {
    
        if (!fName) {
            $("#txtFirstName").addClass( "border border-danger" );
            $('#txtFirstName').attr("placeholder","Please enter a First Name"); 
        }

        if (!lName) {
            $("#txtLastName").addClass( "border border-danger" );
            $('#txtLastName').attr("placeholder","Please enter a Last Name");
        }

        if (!validDouble){
            $('#txtSalary').val('');
            $("#txtSalary").addClass( "border border-danger" );
            $('#txtSalary').attr("placeholder","Please enter a valid number");
            console.error( sal + " Is not a valid number");
        }

        $('#empErrorAlert').show();
        return;
    }

    let emp = {

        Name: fName,
        LastName: lName,
        PhoneNumber: phNum,
        Position: pos,
        Salary: validDouble
    }

    console.log("Sending Employee to server");

    $.ajax({
        type: "POST",
        url: "/Employee/Create",
        data: JSON.stringify(emp),
        contentType: "application/json; charset=utf-8",
        success: function (res) {
            console.log('Employee POST Ended');
            console.log('Server Says: ', res);

            // Clear all input values
            $('#txtFirstName').val('');
            $('#txtLastName').val('');
            $('#txtPhNumber').val('');
            $('#txtPosition').val('');
            $('#txtSalary').val('');

            // Clear all error fields
            $( "#txtSalary" ).removeClass( "border border-danger" );
            $("#txtFirstName").removeClass( "border border-danger" );
            $("#txtLastName").removeClass( "border border-danger" );

            $('#txtFirstName').attr("placeholder",""); 
            $('#txtLastName').attr("placeholder","");
            $('#txtSalary').attr("placeholder","");

            $('#empErrorAlert').hide();
            
        }
    });
}

function GetEmployees() {
    $.ajax({
        type: "GET",
        url: "/Employee/GetAll",
        contentType: "application/json; charset=utf-8",
        success: function (res) {
            console.log('Employee POST Ended');
            console.log('Server Says: ', res);
        },
        error: function (error){
            console.log("error getting data");
            console.log(error);
            
        }
    });
}